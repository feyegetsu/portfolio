// ================= НАСТРОЙКИ: контакты меняются только здесь =================
const CONFIG = {
  telegram: "feyegetsu",           // ник в Telegram без @
  email: "feyegetsu.dev@yandex.ru",
  github: "feyegetsu",
  repo: "https://github.com/feyegetsu/portfolio",
};

const $ = (id) => document.getElementById(id);

// ---------- Контакты ----------
document.querySelectorAll("[data-contact]").forEach((el) => {
  const type = el.dataset.contact;
  if (type === "telegram") el.href = `https://t.me/${CONFIG.telegram}`;
  if (type === "github") el.href = `https://github.com/${CONFIG.github}`;
  if (type === "email") {
    el.textContent = CONFIG.email;
    if (el.tagName === "A") el.href = `mailto:${CONFIG.email}`;
  }
});
document.querySelectorAll("[data-repo-link]").forEach((el) => {
  el.href = `${CONFIG.repo}/tree/main/${el.dataset.repoLink}`;
  el.target = "_blank";
  el.rel = "noopener";
});
$("year").textContent = new Date().getFullYear();

// ---------- Мобильное меню ----------
const burger = $("burger");
const nav = $("nav");
const setMenu = (open) => {
  nav.classList.toggle("open", open);
  burger.classList.toggle("open", open);
  burger.setAttribute("aria-expanded", open);
};
burger.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
nav.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setMenu(false)));

// ---------- Бегущая строка ниш ----------
const niches = [
  ["Кофейни", '<path d="M17 8h1a4 4 0 0 1 0 8h-1M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V8zM6 2v3M10 2v3M14 2v3"/>'],
  ["Доставка еды", '<path d="M5 17a2 2 0 1 0 4 0 2 2 0 1 0-4 0M15 17a2 2 0 1 0 4 0 2 2 0 1 0-4 0M9 17h6M3 11h11V6H3zM14 9h4l3 4v4h-2"/>'],
  ["Рестораны", '<path d="M4 3v8a3 3 0 0 0 6 0V3M7 3v18M17 21V3c-2 1-3 4-3 8h3"/>'],
  ["Барбершопы", '<path d="M6 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM8.1 8.1 20 20M8.1 15.9 20 4"/>'],
  ["Салоны красоты", '<path d="M12 3l2.5 5.5L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.5-.5z"/>'],
  ["Клиники", '<path d="M12 21s-7-4.5-7-11a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 6.5-7 11-7 11zM12 9v5M9.5 11.5h5"/>'],
  ["Фитнес", '<path d="M6 7v10M18 7v10M3 10v4M21 10v4M6 12h12"/>'],
  ["Автосервисы", '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>'],
  ["Цветы", '<path d="M12 22V12M12 12a4 4 0 1 1 4-4 4 4 0 1 1-4 4zM12 12a4 4 0 1 0-4-4M12 18c-3 0-5-2-5-4 2 0 5 1 5 4zM12 18c3 0 5-2 5-4-2 0-5 1-5 4z"/>'],
  ["Недвижимость", '<path d="M3 21h18M5 21V8l7-5 7 5v13M10 21v-6h4v6"/>'],
  ["Стартапы", '<path d="M5 15c-1 1-1.5 4-1.5 4.5S7 20 8 19M14 4c3-1 6-1 6-1s0 3-1 6l-6 6-5-5zM9 10H5l-2 3 4 1M14 15v4l-3 2-1-4"/>'],
];
const tick = niches.map(([n, d]) => `<span><i class="orb"><svg viewBox="0 0 24 24">${d}</svg></i>${n}</span>`).join("");
$("ticker").innerHTML = tick + tick;

// ---------- Кнопка «наверх» ----------
const toTop = $("toTop");
const updateTop = () => {
  const max = document.documentElement.scrollHeight - innerHeight;
  toTop.style.setProperty("--p", max > 0 ? Math.min(1, scrollY / max).toFixed(3) : 0);
  toTop.classList.toggle("show", scrollY > 240);
};
addEventListener("scroll", updateTop, { passive: true });
updateTop();

// ---------- Навигация по разделам справа ----------
// Активный раздел — тот, что пересёк линию на 40% высоты экрана.
// Линия прогресса доходит до чёрточки активного раздела и тянется к следующей по мере его прочтения
const rail = $("rail");
const railLinks = [...rail.querySelectorAll("a")];
const railSecs = railLinks.map((a) => $(a.dataset.sec));
const railLine = rail.querySelector(".rail__line");
const railFill = railLine.querySelector("i");
let railActive = -1, flashTimer;
function updateRail() {
  // На узких экранах полоса скрыта, считать нечего
  if (getComputedStyle(rail).display === "none") return;
  const line = innerHeight * 0.4;
  const tops = railSecs.map((s) => s.getBoundingClientRect().top);
  let i = 0;
  tops.forEach((t, k) => { if (t <= line) i = k; });
  const atEnd = innerHeight + scrollY >= document.documentElement.scrollHeight - 4;
  if (atEnd) i = railSecs.length - 1;
  // Центры чёрточек относительно полосы
  const centers = railLinks.map((a) => a.offsetTop + a.offsetHeight / 2);
  const first = centers[0], last = centers[centers.length - 1];
  railLine.style.top = `${first}px`;
  railLine.style.height = `${last - first}px`;
  let f = 0;
  if (!atEnd && i < railSecs.length - 1) f = Math.min(1, Math.max(0, (line - tops[i]) / (tops[i + 1] - tops[i])));
  const y = atEnd ? last : centers[i] + f * ((centers[i + 1] ?? centers[i]) - centers[i]);
  railFill.style.height = `${y - first}px`;
  if (i === railActive) return;
  railLinks.forEach((a, k) => {
    a.classList.toggle("on", k === i);
    if (k === i) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current");
  });
  if (railActive !== -1) {
    railLinks.forEach((a) => a.classList.remove("flash"));
    railLinks[i].classList.add("flash");
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => railLinks[i].classList.remove("flash"), 1200);
  }
  railActive = i;
}
addEventListener("scroll", updateRail, { passive: true });
addEventListener("resize", updateRail);
updateRail();

// На широких экранах после первого экрана меню шапки уступает место полоске справа
const wide = matchMedia("(min-width: 1280px)");
const updateNavAway = () => document.body.classList.toggle("nav-away", wide.matches && scrollY > innerHeight * 0.55);
addEventListener("scroll", updateNavAway, { passive: true });
wide.addEventListener("change", updateNavAway);
updateNavAway();

// ---------- Работы и кейсы ----------
// goal — задача бизнеса, done — что сделано, tech — как устроено внутри
const projects = [
  { slug: "admin", title: "Админка и API", niche: "Бэкенд", cat: "backend", url: "admin/", code: "backend",
    text: "Общий бэкенд для всех сайтов: заявки, записи, заказы, каталог, роли сотрудников и живая админ-панель.",
    tags: ["FastAPI", "PostgreSQL", "JWT", "pytest", "Docker"],
    goal: "Заявки с сайтов должны куда-то приходить, а владелец должен ими управлять без программиста и без доступа к коду.",
    done: ["API на FastAPI: заявки, запись на время, заказы, каталог, статистика, выгрузка в CSV", "Админка: дашборд, таблицы с поиском и фильтрами, статусы, стоп-лист и цены, команда", "Роли «владелец», «администратор», «сотрудник» и доступ только к своим сайтам", "Все 13 демо-сайтов отправляют формы в API; изменения в админке сразу видны на сайте"],
    tech: ["Двойная запись на один слот невозможна даже при гонке: уникальный ключ в БД, а не проверка в коде", "Цены заказа берутся из каталога на сервере: подменить цену из браузера нельзя", "Валидация телефонов, honeypot от ботов и лимит заявок с одного IP", "25 автотестов на pytest в CI, Docker и docker-compose с PostgreSQL", "На GitHub Pages сервера нет, поэтому клиент работает в демо-режиме: тот же контракт и правила, данные в браузере"] },
  { slug: "miniapp", title: "Сытый Лис", niche: "Telegram Mini App", cat: "tg", phone: true,
    text: "Доставка еды внутри Telegram: меню, размеры пиццы, промокод, оформление и статус заказа.",
    tags: ["Mini App", "Telegram WebApp API", "Тема Telegram"],
    goal: "Ресторану доставки нужен канал заказов без комиссии агрегаторов и без разработки мобильного приложения.",
    done: ["Меню с поиском и «липкими» категориями, которые подсвечиваются при прокрутке", "Шторка товара: размер пиццы и добавки с пересчётом цены", "Корзина, доставка или самовывоз, промокод, бесплатная доставка от суммы", "Оформление с автоподстановкой имени из Telegram и живой статус заказа"],
    tech: ["Цвета берутся из темы Telegram через CSS-переменные SDK, поэтому приложение выглядит родным в светлой и тёмной теме", "Нативные MainButton, BackButton и вибрация; в обычном браузере их заменяют свои элементы", "Всё на чистом JS, без сборки: открывается мгновенно даже на слабом интернете"] },
  { slug: "restaurant", title: "Ресторан «Терруар»", niche: "Ресторан", cat: "food", isNew: true,
    text: "Ресторан сезонной кухни: дегустационный сет по сезонам, винное сопровождение и бронь стола по слотам.",
    tags: ["Бронь стола", "Сезонное меню", "Сертификаты"],
    goal: "Ресторану высокой кухни нужно продавать не блюда, а впечатление и заполнять 28 мест бронями заранее.",
    done: ["Четыре сезонных меню: при смене сезона меняются подачи, описания и вина, текущий сезон выбран сам", "Лента из шести подач и переключатель винного сопровождения с пересчётом цены", "Бронь: дата, свободное время, число гостей, повод и сумма ужина на всех", "Подарочные сертификаты, история шефа и фотоальбомы зала, кухни и погреба"],
    tech: ["Бронь уходит в общий API и сразу видна в админке в разделе «Записи»", "Прошедшее время и выходной день недоступны, по умолчанию выбран ближайший день со свободными столами", "Шрифтовая пара Prata и IBM Plex Sans, бронь в шапке, как у Noma и Gaggan"] },
  { slug: "sushi", title: "Суши «Кайсэн»", niche: "Доставка суши", cat: "food", isNew: true,
    text: "Доставка суши: проверка зоны доставки, корзина с палочками, стоп-лист из админки и отслеживание заказа.",
    tags: ["Доставка", "Каталог из админки", "Статус заказа"],
    goal: "Суши-бару нужен свой канал заказов без комиссии агрегаторов, где цены и стоп-лист меняют без программиста.",
    done: ["Меню по разделам с липкой навигацией, которая подсвечивает текущий раздел", "Проверка района: время в пути и условия бесплатной доставки", "Корзина-шторка: количество, палочки на персон, доставка или самовывоз, прогресс до бесплатной доставки", "После заказа экран статуса: принят, готовим, курьер в пути, доставлено"],
    tech: ["Цены и наличие приходят из каталога API: администратор ставит позицию в стоп-лист, и она сразу недоступна на сайте", "Итог заказа сервер считает по своим ценам, подменить цену из браузера нельзя", "Корзина и район сохраняются между визитами"] },
  { slug: "gastrobar", title: "Гастробар «Соль и Солод»", niche: "Гастробар", cat: "food", isNew: true,
    text: "Гастробар: меловая доска дня, краны с фильтром по стилю, подбор пива к блюду, афиша с записью и бронь.",
    tags: ["Афиша", "Подбор пары", "Счастливые часы"],
    goal: "Гастробару нужно, чтобы гости приходили не только поесть, а на события, и бронировали столы на квиз и концерты.",
    done: ["Статус «прямо сейчас»: открыто или закрыто, идут ли счастливые часы, всё по текущему времени", "Меловая доска с блюдами дня: сегодняшний день выбран сам, остальные можно посмотреть", "Краны с крепостью и горечью, фильтр по стилю и цены со скидкой в счастливые часы", "Подбор пива к блюду, афиша недели с записью и бронь по зонам"],
    tech: ["Запись на событие и бронь стола уходят в API и видны в админке", "Афиша строится от сегодняшней даты: всегда ближайшие события", "Индустриальная типографика: Fira Sans Extra Condensed и рукописный Amatic SC для доски"] },
  { slug: "bar", title: "Бар «Полночь»", niche: "Коктейльный бар", cat: "food", isNew: true,
    text: "Спикизи-бар: проверка возраста, неоновая вывеска, коктейли по вкусу, подбор коктейля, гест-лист и бронь.",
    tags: ["18+", "Квиз", "Гест-лист"],
    goal: "Бару без вывески нужно сохранить атмосферу секретного места и при этом собирать брони и гест-лист.",
    done: ["Проверка возраста 18+ при первом входе", "«Постучите три раза» открывает пароль дня и кнопку брони", "Коктейли с фильтром по вкусу, крепостью и рецептом при наведении", "Подбор коктейля за три вопроса, вечера недели с гест-листом и бронь стойки, дивана или кабинета"],
    tech: ["Бронь после полуночи записывается на правильную дату", "Гест-лист и бронь уходят в API и видны в админке", "На сенсорных экранах рецепт открывается отдельной кнопкой, а не наведением"] },
  { slug: "florist", title: "Пион & Ко", niche: "Интернет-магазин", cat: "shop",
    text: "Магазин цветов: каталог с фильтрами, корзина с сохранением, оформление доставки.",
    tags: ["Корзина", "Фильтры", "localStorage"],
    goal: "Цветочной мастерской нужен магазин, где букет можно выбрать и оформить с телефона за минуту.",
    done: ["Каталог с фильтром по категориям и сортировкой по цене и популярности", "Выезжающая корзина с изменением количества и подсказкой до бесплатной доставки", "Оформление: адрес, дата и интервал доставки", "Подписка на цветы и быстрая кнопка «В корзину» на фото"],
    tech: ["Корзина хранится в localStorage и переживает перезагрузку; без него страница тоже работает", "Закрытие корзины по Esc и по клику на фон, блокировка прокрутки под ней", "Анимации отключаются при системной настройке «уменьшить движение»"] },
  { slug: "dental", title: "Стоматология «Белая линия»", niche: "Медицина", cat: "services",
    text: "Клиника с прайсом по вкладкам и квизом, который считает стоимость лечения.",
    tags: ["Квиз", "Прайс", "Лиды"],
    goal: "Клинике нужно снять страх «сколько это будет стоить» и получать больше заявок на первичную консультацию.",
    done: ["Квиз из трёх вопросов с расчётом примерной стоимости и закреплением скидки", "Прайс по направлениям, переключается без перезагрузки", "Кликабельные карточки врачей и клиники: специализация, график, оборудование", "Кнопка «Записаться к врачу» сама выбирает врача в форме записи"],
    tech: ["Квиз — маленький конечный автомат: шаги и итог считаются из данных, вопросы легко менять", "Обязательная медицинская оговорка в подвале", "Счётчики и появление блоков из общего модуля анимаций"] },
  { slug: "cafe", title: "Кофейня «Зерно»", niche: "Общепит", cat: "food",
    text: "Сайт кофейни в стиле газеты: печатное меню, полароиды атмосферы и бронь столика.",
    tags: ["Меню", "Бронь", "Редакционная вёрстка"],
    goal: "Кофейне нужен сайт, который передаёт атмосферу и превращает просмотр меню в визит.",
    done: ["Вёрстка в стиле газеты: шапка с датой выпуска, статья в три колонки, буквица", "Меню как печатная карта: название, точки до цены, переключение разделов", "Полароиды атмосферы и бронь столика в виде билета"],
    tech: ["Нельзя выбрать прошедшую дату брони", "Фото подгружаются лениво и в нужном размере", "Надпись по кругу на печати сделана SVG-текстом по контуру"] },
  { slug: "barbershop", title: "Барбершоп BLADE", niche: "Красота", cat: "services",
    text: "Олдскульная вывеска и онлайн-запись в 3 шага: услуга, мастер, свободное время.",
    tags: ["Онлайн-запись", "Слоты"],
    goal: "Барбершопу нужно разгрузить администратора: клиенты должны записываться сами, в любое время.",
    done: ["Запись в три шага с прогресс-баром и сводкой перед подтверждением", "Календарь на неделю, занятые и прошедшие слоты недоступны", "Вывеска с эмблемой, фото в золотой раме и прайс в виде таблички"],
    tech: ["Сегодняшние слоты, которые уже прошли, блокируются по текущему времени", "Занятость слотов стабильна для каждого дня и не прыгает при переключении", "Чёрно-белые фото становятся цветными при наведении"] },
  { slug: "fitness", title: "Фитнес-клуб PULSE", niche: "Спорт", cat: "services",
    text: "Сайт-плакат: расписание на неделю с записью и абонементы с переключением периода.",
    tags: ["Расписание", "Тарифы"],
    goal: "Клубу нужно, чтобы клиенты сами записывались на групповые занятия и видели свободные места.",
    done: ["Расписание на 7 дней с фильтром по типу тренировок", "Запись и отмена в один клик, счётчик свободных мест", "Первый экран как спортивный плакат и направления-полосы, которые раскрываются по наведению"],
    tech: ["Расписание и заполненность генерируются из данных для каждого дня", "Пустой результат фильтра показывает подсказку, а не пустоту", "Живой счётчик «сейчас в клубе»"] },
  { slug: "autoservice", title: "Автосервис «МоторЛайн»", niche: "Авто", cat: "services",
    text: "Калькулятор стоимости ремонта и отслеживание статуса машины по номеру заказа.",
    tags: ["Калькулятор", "Статус заказа"],
    goal: "Автосервису нужно вызвать доверие: честная цена до визита и прозрачный ремонт.",
    done: ["Калькулятор: тип машины меняет коэффициент, итог и время работ считаются сразу", "Запись на ремонт прямо из калькулятора", "«Где моя машина?»: этапы ремонта по номеру заказа"],
    tech: ["Итог плавно «набегает», но всегда приходит к точной сумме, даже в фоновой вкладке", "Номер заказа экранируется перед выводом на страницу", "Иконки нарисованы SVG, без шрифтов-иконок"] },
  { slug: "realty", title: "Агентство «Квадрат»", niche: "Недвижимость", cat: "shop",
    text: "Каталог квартир с фильтрами и избранным, карточка объекта с галереей, ипотечный калькулятор.",
    tags: ["Каталог", "Ипотека", "Галерея"],
    goal: "Агентству нужен каталог, где клиент быстро сужает выбор и сразу понимает платёж по ипотеке.",
    done: ["Фильтры по комнатам, цене, типу и району, избранное", "Карточка объекта с галереей и платежом по ипотеке", "Ипотечный калькулятор с программами и долей переплаты"],
    tech: ["Аннуитетный платёж по формуле банка, переплата на круговой диаграмме", "Избранное сохраняется между визитами", "Карточки открываются и с клавиатуры, модалка закрывается по Esc"] },
  { slug: "saas", title: "Taskly", niche: "IT-стартап", cat: "startup",
    text: "Лендинг SaaS-сервиса с интерактивной канбан-доской и расчётом тарифа по числу людей.",
    tags: ["Drag & Drop", "Тарифы"],
    goal: "Стартапу нужно показать продукт в действии прямо на лендинге и довести до регистрации.",
    done: ["Канбан-доска на первом экране: карточки перетаскиваются между колонками", "Тарифы с ползунком числа участников и скидкой за год", "Bento-сетка возможностей, отзывы и FAQ"],
    tech: ["Перетаскивание работает и мышью (HTML5 DnD), и пальцем (свои touch-события)", "Конфетти при переносе задачи в «Готово»", "Карточки вставляются по позиции курсора, а не только в конец"] },
  { slug: "cafe-bot", title: "Бот для заказов", niche: "Telegram-бот", cat: "tg", bot: true,
    text: "Бот кафе на aiogram 3: меню, корзина, заказы в SQLite, уведомления админу, рассылки.",
    tags: ["Python", "aiogram 3", "SQLite"],
    goal: "Кафе нужно принимать заказы в Telegram и мгновенно передавать их на кухню.",
    done: ["Меню и корзина на inline-кнопках", "Заказ сохраняется в базу и приходит администратору", "Кнопка «Готов» у админа уведомляет клиента", "Рассылка акций командой /broadcast"],
    tech: ["aiogram 3, асинхронный polling", "Токен и ID админа в .env, в репозитории только пример", "Проверка кода в CI на каждый пуш"] },
];
const cats = { all: "Все", backend: "Бэкенд", tg: "Telegram", services: "Услуги", shop: "Магазины", food: "Общепит", startup: "Стартапы" };
const caseUrl = (p) => p.url || (p.bot ? "#bot" : `projects/${p.slug}/`);
const codeUrl = (p) => `${CONFIG.repo}/tree/main/${p.code || `projects/${p.slug}`}`;

$("filters").innerHTML = Object.entries(cats)
  .map(([k, v], i) => `<button class="chip${i ? "" : " active"}" aria-pressed="${!i}" data-cat="${k}">${v}<span>${k === "all" ? projects.length : projects.filter((p) => p.cat === k).length}</span></button>`)
  .join("");

function workCard(p) {
  const preview = p.bot
    ? `<div class="work__bot"><div class="mini-msg">📋 Меню</div><div class="mini-msg mini-msg--me">☕ Капучино ×2</div><div class="mini-msg">🎉 Заказ №4821 принят!</div></div>`
    : `<img class="work__shot" src="assets/previews/${p.slug}.jpg" alt="" loading="lazy" decoding="async" data-slug="${p.slug}">`;
  return `
    <article class="work" data-cat="${p.cat}">
      <button class="work__preview${p.bot ? " work__preview--bot" : ""}" data-case="${p.slug}" aria-label="Кейс: ${p.title}">
        ${preview}
        ${p.isNew ? '<span class="work__new">Новое</span>' : ""}
        <span class="work__open">Смотреть кейс</span>
      </button>
      <div class="work__body">
        <span class="work__niche">${p.niche}</span>
        <h3>${p.title}</h3>
        <p>${p.text}</p>
        <ul class="tags">${p.tags.map((t) => `<li>${t}</li>`).join("")}</ul>
        <div class="work__links">
          <button data-case="${p.slug}">Подробнее о кейсе</button>
          <a href="${caseUrl(p)}"${p.bot ? "" : ' target="_blank" rel="noopener"'}>${p.bot ? "Демо ↓" : "Открыть ↗"}</a>
        </div>
      </div>
    </article>`;
}
$("worksGrid").innerHTML = projects.map(workCard).join("");

// Если скриншота ещё нет, показываем живой сайт в уменьшенном iframe
document.querySelectorAll(".work__shot").forEach((img) => {
  img.addEventListener("error", () => {
    const f = document.createElement("iframe");
    f.src = caseUrl(projects.find((p) => p.slug === img.dataset.slug));
    f.title = "Превью";
    f.tabIndex = -1;
    f.setAttribute("aria-hidden", "true");
    f.loading = "lazy";
    img.replaceWith(f);
    const fit = () => { f.style.transform = `scale(${f.parentElement.clientWidth / 1280})`; };
    fit();
    new ResizeObserver(fit).observe(f.parentElement);
  }, { once: true });
});

$("filters").addEventListener("click", (e) => {
  const b = e.target.closest(".chip");
  if (!b) return;
  document.querySelectorAll(".chip").forEach((c) => {
    c.classList.toggle("active", c === b);
    c.setAttribute("aria-pressed", c === b);
  });
  document.querySelectorAll(".work").forEach((w) => {
    w.hidden = b.dataset.cat !== "all" && w.dataset.cat !== b.dataset.cat;
  });
});

// ---------- Модалка кейса ----------
const caseEl = $("case");
let caseIdx = -1;
let lastFocus = null;

function openCase(slug, push = true) {
  const i = projects.findIndex((p) => p.slug === slug);
  if (i < 0) return;
  const p = projects[i];
  caseIdx = i;
  if (!caseEl.open) {
    lastFocus = document.activeElement;
    caseEl.showModal();
    document.body.classList.add("lock");
  }
  const device = p.phone || p.bot || matchMedia("(max-width: 760px)").matches ? "phone" : "desktop";
  caseEl.querySelector(".case__inner").innerHTML = `
    <div class="case__stage">
      <div class="case__devices" role="group" aria-label="Устройство">
        <button data-device="desktop" aria-pressed="${device === "desktop"}" ${p.bot ? "disabled" : ""}>Компьютер</button>
        <button data-device="phone" aria-pressed="${device === "phone"}">Телефон</button>
      </div>
      <div class="frame frame--${device}" id="caseFrame"><div class="frame__screen">
        ${p.bot
          ? `<div class="case__bot"><div class="mini-msg">Привет! 👋 Я бот кофейни «Зерно»</div><div class="mini-msg mini-msg--me">📋 Меню</div><div class="mini-msg">☕ Кофе\n• Капучино — 220 ₽\n• Латте — 240 ₽</div><div class="mini-msg mini-msg--me">✅ Оформить</div><div class="mini-msg">🎉 Заказ №4821 принят!</div><a class="btn btn--small" href="#bot" data-close>Попробовать симуляцию ↓</a></div>`
          : `<iframe src="${caseUrl(p)}${p.phone ? "?embed" : ""}" title="Демо: ${p.title}" loading="lazy"></iframe>`}
      </div></div>
      <p class="case__hint">${p.bot ? "Живая симуляция бота ниже на странице" : "Сайт живой: можно кликать прямо здесь"}</p>
      ${p.bot ? "" : `<a class="btn case__open" href="${caseUrl(p)}" target="_blank" rel="noopener">Открыть на весь экран ↗</a>`}
    </div>
    <article class="case__text">
      <span class="work__niche">${p.niche}</span>
      <h2 id="caseTitle">${p.title}</h2>
      <p class="case__lead">${p.text}</p>
      <h3>Задача</h3><p>${p.goal}</p>
      <h3>Что сделано</h3><ul class="checks">${p.done.map((d) => `<li>${d}</li>`).join("")}</ul>
      <h3>Под капотом</h3><ul class="case__tech">${p.tech.map((d) => `<li>${d}</li>`).join("")}</ul>
      <ul class="tags">${p.tags.map((t) => `<li>${t}</li>`).join("")}</ul>
      <div class="case__actions">
        ${p.bot ? "" : `<a class="btn case__site" href="${caseUrl(p)}" target="_blank" rel="noopener">Открыть сайт ↗</a>`}
        <a class="btn btn--ghost" href="${codeUrl(p)}" target="_blank" rel="noopener">Код на GitHub</a>
      </div>
      <div class="case__nav">
        <button data-step="-1">← ${projects[(i - 1 + projects.length) % projects.length].title}</button>
        <button data-step="1">${projects[(i + 1) % projects.length].title} →</button>
      </div>
    </article>`;
  caseEl.setAttribute("aria-labelledby", "caseTitle");
  fitCaseFrame();
  caseEl.querySelector(".case__scroll").scrollTop = 0;
  if (push) history.replaceState(null, "", `#case-${slug}`);
}

// В режиме «Компьютер» сайт рендерится на ширине 1280px и уменьшается под рамку, как настоящий монитор
function fitCaseFrame() {
  const frame = $("caseFrame");
  const f = frame && frame.querySelector("iframe");
  if (!f) return;
  // В режиме «Телефон» на узком экране сайт рисуется на ширине обычного смартфона (390px) и тоже уменьшается
  const base = frame.classList.contains("frame--desktop") ? 1280 : frame.clientWidth < 390 ? 390 : 0;
  if (base) {
    const k = frame.clientWidth / base;
    Object.assign(f.style, { width: `${base}px`, height: `${frame.clientHeight / k}px`, transform: `scale(${k})`, transformOrigin: "0 0", position: "absolute", top: "0", left: "0" });
  } else {
    Object.assign(f.style, { width: "", height: "", transform: "", position: "", top: "", left: "" });
  }
}
addEventListener("resize", () => caseEl.open && fitCaseFrame());
// Рамка меняет размер с анимацией: пересчитываем масштаб, когда она закончилась
caseEl.addEventListener("transitionend", (e) => { if (e.target.id === "caseFrame" && e.propertyName === "width") fitCaseFrame(); });

// Уборка после закрытия делается сразу, не дожидаясь события close: в фоновых вкладках оно может прийти с опозданием
function cleanupCase(restoreFocus = true) {
  if (!document.body.classList.contains("lock")) return;
  document.body.classList.remove("lock");
  caseEl.querySelector(".case__inner").innerHTML = "";
  if (location.hash.startsWith("#case-")) history.replaceState(null, "", "#works");
  // preventScroll: иначе фокус прокручивает страницу обратно к карточке
  if (lastFocus && restoreFocus) lastFocus.focus({ preventScroll: true });
}
function closeCase(restoreFocus = true) {
  if (caseEl.open) caseEl.close();
  cleanupCase(restoreFocus);
}
caseEl.addEventListener("cancel", (e) => {
  e.preventDefault();
  closeCase();
});
caseEl.addEventListener("close", () => cleanupCase());
caseEl.addEventListener("click", (e) => {
  if (e.target === caseEl) return closeCase();
  const t = e.target.closest("button, a");
  if (!t) return;
  if (t.matches("[data-close]")) {
    if (t.getAttribute("href") === "#bot") {
      e.preventDefault();
      closeCase(false);
      // Прыжок к симуляции: после закрытия окна, когда страница снова прокручивается
      history.replaceState(null, "", "#bot");
      setTimeout(() => $("bot").querySelector(".phone").scrollIntoView({ behavior: "smooth", block: "center" }), 30);
    } else closeCase();
    return;
  }
  if (t.dataset.step) openCase(projects[(caseIdx + +t.dataset.step + projects.length) % projects.length].slug);
  if (t.dataset.device && !t.disabled) {
    $("caseFrame").className = `frame frame--${t.dataset.device}`;
    caseEl.querySelectorAll("[data-device]").forEach((b) => b.setAttribute("aria-pressed", b === t));
    // ждём, пока рамка поменяет размер
    setTimeout(fitCaseFrame, 460);
    fitCaseFrame();
  }
});
caseEl.addEventListener("keydown", (e) => {
  if (e.target.closest("input, textarea")) return;
  if (e.key === "ArrowRight") openCase(projects[(caseIdx + 1) % projects.length].slug);
  if (e.key === "ArrowLeft") openCase(projects[(caseIdx - 1 + projects.length) % projects.length].slug);
});
document.addEventListener("click", (e) => {
  const t = e.target.closest("[data-case]");
  if (t && !caseEl.contains(t)) openCase(t.dataset.case);
});
// Прямые ссылки вида #case-florist
const fromHash = () => {
  const m = location.hash.match(/^#case-([\w-]+)$/);
  if (m) openCase(m[1], false);
};
addEventListener("hashchange", fromHash);
fromHash();

// ---------- Услуги ----------
const icon = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const services = [
  [icon('<path d="M17 8h1a4 4 0 0 1 0 8h-1M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V8zM6 2v3M10 2v3M14 2v3"/>'), "Сайт для кафе и ресторана", "Меню с ценами, бронь столика, карта, часы работы. Гость за минуту понимает, почему стоит прийти именно к вам."],
  [icon('<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 17h4v4"/>'), "QR-меню", "Электронное меню по QR-коду на столе. Цены меняете сами за секунды, без перепечатки."],
  [icon('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>'), "Онлайн-запись", "Для салонов, клиник, барбершопов и автосервисов: услуга, мастер, время. Заявка сразу приходит в Telegram."],
  [icon('<path d="M21 4 3 11l6 2 2 6 3-4 5 4 2-15z"/><path d="m9 13 8-6"/>'), "Telegram-боты", "Приём заказов, запись, рассылки, ответы на частые вопросы, оплата. Бот работает круглосуточно."],
  [icon('<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>'), "Магазины и каталоги", "Каталог с фильтрами, корзина, оформление заказа. Заказы приходят в Telegram или CRM."],
  [icon('<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 10h8M8 14h2M14 14h2M8 18h2M14 18h2"/>'), "Калькуляторы и квизы", "Расчёт стоимости прямо на сайте. Клиент видит цену и оставляет заявку охотнее."],
];
$("servicesGrid").innerHTML = services
  .map(([ic, t, d]) => `<article class="card"><div class="card__icon">${ic}</div><h3>${t}</h3><p>${d}</p></article>`)
  .join("");

// ---------- Появление при прокрутке ----------
const io = new IntersectionObserver((entries) => entries.forEach((e) => {
  if (e.isIntersecting) { e.target.classList.add("visible"); io.unobserve(e.target); }
}), { threshold: 0.1 });
document.querySelectorAll(".card, .work, .steps li, .why__item, .faq, .calc").forEach((el) => {
  el.classList.add("reveal");
  io.observe(el);
});

// ---------- Живость: подсветка за курсором, «магнитные» кнопки, счётчики ----------
const finePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;
const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
if (finePointer && !reduceMotion) {
  document.addEventListener("pointermove", (e) => {
    const el = e.target.closest(".card, .work, .why__item, .steps li");
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${e.clientX - r.left}px`);
    el.style.setProperty("--my", `${e.clientY - r.top}px`);
  });
  document.querySelectorAll(".hero__actions .btn, .contact__links .btn, .header .btn").forEach((b) => {
    b.addEventListener("pointermove", (e) => {
      const r = b.getBoundingClientRect();
      b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.18}px, ${(e.clientY - r.top - r.height / 2) * 0.3}px)`;
    });
    b.addEventListener("pointerleave", () => { b.style.transform = ""; });
  });
}

const countIO = new IntersectionObserver((entries) => entries.forEach((e) => {
  if (!e.isIntersecting) return;
  const el = e.target;
  const to = +el.dataset.count;
  countIO.unobserve(el);
  if (reduceMotion) return;
  el.style.minWidth = `${el.getBoundingClientRect().width}px`;
  el.style.fontVariantNumeric = "tabular-nums";
  const start = performance.now();
  const step = (t) => {
    const p = Math.min(1, (t - start) / 1200);
    el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
  setTimeout(() => { el.textContent = to; }, 1400);
}));
document.querySelectorAll("[data-count]").forEach((el) => countIO.observe(el));

// ---------- Симуляция Telegram-бота ----------
const chat = $("chat");
const keys = $("keys");
const menu = {
  "☕ Кофе": [{ name: "Капучино", price: 220 }, { name: "Латте", price: 240 }, { name: "Флэт уайт", price: 260 }],
  "🥐 Выпечка": [{ name: "Круассан", price: 180 }, { name: "Синнабон", price: 210 }],
  "🍰 Десерты": [{ name: "Чизкейк", price: 290 }, { name: "Тирамису", price: 320 }],
};
let cart = [];
const cartTotal = () => cart.reduce((s, i) => s + i.price, 0);

function addMsg(text, who = "bot") {
  const el = document.createElement("div");
  el.className = `msg msg--${who}`;
  el.textContent = text;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}

// Пока бот «печатает», старые кнопки остаются на месте, но не нажимаются:
// раскладка не прыгает, и второй быстрый тап не попадает в новую кнопку
let keysReadyAt = 0;
function setKeys(buttons) {
  keys.innerHTML = "";
  keys.classList.remove("busy");
  keysReadyAt = performance.now() + 250;
  buttons.forEach(({ label, action, wide }) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    if (wide) b.classList.add("wide");
    b.addEventListener("click", () => {
      if (keys.classList.contains("busy") || performance.now() < keysReadyAt) return;
      keys.classList.add("busy");
      addMsg(label, "user");
      botReply(action);
    });
    keys.appendChild(b);
  });
}

function botReply(action) {
  $("botStatus").textContent = "печатает…";
  setTimeout(() => {
    $("botStatus").textContent = "бот";
    action();
  }, 550);
}

function showMain() {
  addMsg("Выберите, что хотите сделать 👇");
  setKeys([
    { label: "📋 Меню", action: showCategories },
    { label: `🛒 Корзина (${cart.length})`, action: showCart },
    { label: "📍 Адрес и часы", action: showInfo, wide: true },
  ]);
}

function showCategories() {
  addMsg("Выберите категорию:");
  setKeys([
    ...Object.keys(menu).map((cat) => ({ label: cat, action: () => showCategory(cat) })),
    { label: "⬅️ Назад", action: showMain },
  ]);
}

function showCategory(cat) {
  addMsg(`${cat}\n\n` + menu[cat].map((i) => `• ${i.name} — ${i.price} ₽`).join("\n"));
  setKeys([
    ...menu[cat].map((item) => ({
      label: `+ ${item.name}`,
      action: () => {
        cart.push(item);
        addMsg(`✅ ${item.name} в корзине.\nСумма: ${cartTotal()} ₽`);
        showCategory(cat);
      },
    })),
    { label: "⬅️ Категории", action: showCategories },
    { label: `🛒 Корзина (${cart.length})`, action: showCart },
  ]);
}

function showCart() {
  if (!cart.length) {
    addMsg("Корзина пока пуста 🙂");
    return showMain();
  }
  addMsg("🛒 Ваш заказ:\n\n" + cart.map((i) => `• ${i.name} — ${i.price} ₽`).join("\n") + `\n\nИтого: ${cartTotal()} ₽`);
  setKeys([
    { label: "✅ Оформить", action: checkout },
    { label: "🗑 Очистить", action: () => { cart = []; addMsg("Корзина очищена."); showMain(); } },
    { label: "⬅️ В меню", action: showMain, wide: true },
  ]);
}

function checkout() {
  const num = Math.floor(1000 + Math.random() * 9000);
  addMsg(`🎉 Заказ №${num} принят!\nСумма: ${cartTotal()} ₽\n\nБудет готов через 10–15 минут.`);
  cart = [];
  setTimeout(() => addMsg("☕ Ваш заказ готов! Заберите его на кассе."), 1800);
  setTimeout(() => setKeys([{ label: "🔄 Начать заново", action: startBot, wide: true }]), 2000);
}

function showInfo() {
  addMsg("📍 ул. Примерная, 12\n🕗 Ежедневно 8:00–22:00\n📞 +7 (900) 000-00-00");
  showMain();
}

function startBot() {
  chat.innerHTML = "";
  cart = [];
  addMsg("Привет! 👋 Я бот кофейни «Зерно».\nПомогу сделать заказ без очереди.");
  showMain();
}
startBot();

// ---------- Калькулятор стоимости ----------
const calcTypes = [
  { id: "landing", name: "Лендинг", desc: "1 страница", price: 15000, days: 5 },
  { id: "site", name: "Сайт заведения", desc: "до 5 страниц", price: 30000, days: 10 },
  { id: "shop", name: "Магазин / каталог", desc: "корзина, фильтры", price: 45000, days: 14 },
  { id: "bot", name: "Telegram-бот", desc: "меню и заказы", price: 10000, days: 4 },
  { id: "botpro", name: "Бот с записью", desc: "напоминания, оплата", price: 20000, days: 8 },
  { id: "miniapp", name: "Telegram Mini App", desc: "приложение в Telegram", price: 40000, days: 14 },
];
const BOT_TYPES = ["bot", "botpro", "miniapp"];
// Пилотная скидка за отзыв и предоплата для первых клиентов
const PILOT = { discount: 0.25, prepay: 0.3 };
const calcOpts = [
  { id: "booking", name: "Онлайн-запись или бронь", price: 7000, days: 2 },
  { id: "calc", name: "Калькулятор или квиз", price: 6000, days: 2 },
  { id: "tg", name: "Заявки в Telegram", price: 0, days: 0 },
  { id: "bot", name: "Telegram-бот к сайту", price: 10000, days: 3 },
  { id: "admin", name: "Админка для цен и меню", price: 12000, days: 3 },
  { id: "texts", name: "Тексты и подбор фото", price: 5000, days: 1 },
];
const calcState = { type: "site", opts: new Set(["tg"]), k: 1, pilot: true };
const priceLabel = (o) => (o.price ? `+${o.price.toLocaleString("ru-RU")} ₽` : "бесплатно");

$("calcTypes").innerHTML = calcTypes
  .map((t) => `<button type="button" class="calc__type${t.id === calcState.type ? " active" : ""}" data-id="${t.id}"><b>${t.name}</b><small>${t.desc} · от ${t.price.toLocaleString("ru-RU")} ₽</small></button>`)
  .join("");
$("calcOpts").innerHTML = calcOpts
  .map((o) => `<label class="calc__opt"><input type="checkbox" value="${o.id}"${calcState.opts.has(o.id) ? " checked" : ""}><span>${o.name}</span><em${o.price ? "" : ' class="free"'}>${priceLabel(o)}</em></label>`)
  .join("");

$("calcTypes").addEventListener("click", (e) => {
  const b = e.target.closest(".calc__type");
  if (!b) return;
  calcState.type = b.dataset.id;
  document.querySelectorAll(".calc__type").forEach((x) => x.classList.toggle("active", x === b));
  renderCalc();
});
$("calcOpts").addEventListener("change", (e) => {
  e.target.checked ? calcState.opts.add(e.target.value) : calcState.opts.delete(e.target.value);
  renderCalc();
});
$("calcPilot").addEventListener("change", (e) => {
  calcState.pilot = e.target.checked;
  renderCalc();
});
$("calcSpeed").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  calcState.k = +b.dataset.k;
  $("calcSpeed").querySelectorAll("button").forEach((x) => x.classList.toggle("active", x === b));
  renderCalc();
});

let calcShown = 0;
let calcText = "";
function renderCalc() {
  const type = calcTypes.find((t) => t.id === calcState.type);
  // К боту или Mini App ещё один бот не добавляем
  const opts = calcOpts.filter((o) => calcState.opts.has(o.id) && !(BOT_TYPES.includes(type.id) && o.id === "bot"));
  const base = type.price + opts.reduce((s, o) => s + o.price, 0);
  const full = Math.round((base * calcState.k) / 1000) * 1000;
  const sum = calcState.pilot ? Math.round((full * (1 - PILOT.discount)) / 500) * 500 : full;
  const days = Math.max(3, Math.ceil((type.days + opts.reduce((s, o) => s + o.days, 0)) / (calcState.k > 1 ? 1.5 : 1)));
  const rub = (n) => `${n.toLocaleString("ru-RU")} ₽`;
  $("calcList").innerHTML = [`<li><span>${type.name}</span><span>${rub(type.price)}</span></li>`,
    ...opts.map((o) => `<li><span>${o.name}</span><span>${priceLabel(o)}</span></li>`),
    calcState.k > 1 ? `<li><span>Срочность</span><span>+30%</span></li>` : "",
    calcState.pilot ? `<li class="calc__pilot"><span>Пилотная скидка за отзыв</span><span>−25%</span></li>` : ""].join("");
  $("calcOld").textContent = calcState.pilot ? `от ${rub(full)}` : "";
  $("calcDays").textContent = `Срок: ~${days} ${days % 10 === 1 && days !== 11 ? "день" : days % 10 >= 2 && days % 10 <= 4 && (days < 10 || days > 20) ? "дня" : "дней"}`;
  $("calcPay").innerHTML = `Предоплата ${PILOT.prepay * 100}%: <b>${rub(Math.round((sum * PILOT.prepay) / 100) * 100)}</b>, остальное после сдачи`;
  calcText = `Здравствуйте! Посчитал проект на сайте:\n• ${type.name}\n${opts.map((o) => `• ${o.name}`).join("\n")}${calcState.k > 1 ? "\n• Срочно" : ""}${calcState.pilot ? "\n• Пилотная скидка −25% за отзыв" : ""}\nИтого: от ${rub(sum)}, ~${days} дн.`;
  animateNumber(sum);
}
function animateNumber(to) {
  // Страховка: если браузер не даёт анимировать (свёрнутое окно), итог всё равно появится
  clearTimeout(animateNumber.done);
  animateNumber.done = setTimeout(() => {
    calcShown = to;
    $("calcSum").textContent = `от ${to.toLocaleString("ru-RU")} ₽`;
  }, 500);
  const from = calcShown;
  const start = performance.now();
  const step = (t) => {
    const p = Math.min(1, (t - start) / 450);
    calcShown = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
    $("calcSum").textContent = `от ${calcShown.toLocaleString("ru-RU")} ₽`;
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
$("calcSend").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(calcText);
    toast("Расчёт скопирован. Вставьте его в чат");
  } catch {
    toast("Откройте чат и опишите проект");
  }
  window.open(`https://t.me/${CONFIG.telegram}`, "_blank", "noopener");
});
renderCalc();

// ---------- Уведомления ----------
let toastTimer;
function toast(msg) {
  $("toast").textContent = msg;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2600);
}
